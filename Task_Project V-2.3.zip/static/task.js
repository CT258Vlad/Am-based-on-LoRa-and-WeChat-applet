$(document).ready(function(){
    var userRole = localStorage.getItem('userRole');
    if(userRole ==  1){
        $("#admin").hide();
    }else{
        $("#user").hide();
    }
    var DeviceOwnner = localStorage.getItem("DeviceOwnner");
    var DeviceUser = localStorage.getItem('DeviceUser');
    var DeviceCode = localStorage.getItem('DeviceCode');
    var now = (new Date(Date.now())).getTime()/1000;
    var d1 = (new Date(Date.now()+7*24*60*60*1000)).getTime()/1000;
    var d2 = (new Date(Date.now()+10*24*60*60*1000)).getTime()/1000;
    var TaskCode;
    $("#send_btn").click(function(){
        var date1=document.getElementById("start-date");
        var time1=document.getElementById("start-time");
        var send_btn = document.getElementById("send_btn");
        var date2=document.getElementById("end-date");
        var time2=document.getElementById("end-time");
        var a = date1.value+" "+time1.value;
        var b = date2.value+" "+time2.value;
        var start_time = (new Date(a.toString())).getTime()/1000;
        var end_time = (new Date(b.toString())).getTime()/1000;
        if(start_time>now){
            if(start_time<d1){
                if(end_time>d1){
                    if(end_time<d2){
                        if((userRole == 2)||(userRole == 3)){
                            $.ajax({
                                async: true,
                                type: "POST",
                                url: "http://47.102.42.105:8181/Task/AddEffectiveTask",
                                dataType: "json",
                                contentType: "application/json",
                                data: JSON.stringify({
                                    "DeviceCode":DeviceCode,
                                    "DeviceOwnner":DeviceOwnner,
                                    "DeviceUser":DeviceUser,
                                    "StartTime":start_time,
                                    "EndTime":end_time,
                                    "Desc":"Desc"
                                }),
                                success: function (data) {
                                    alert("设置成功！");
                                    TaskCode = data.TaskCode;
                                    flag = 1;
                                },
                                error: function (data) {
                                    alert("设置失败！");
                                    flag = 0;
                                }
                            });
                        }else if(userRole == 1){
                            $.ajax({
                                async: true,
                                type: "POST",
                                url: "http://47.102.42.105:8181/Task/AddApplyTask",
                                dataType: "json",
                                contentType: "application/json",
                                data: JSON.stringify({
                                    "DeviceCode":DeviceCode,
                                    "DeviceOwnner":DeviceOwnner,
                                    "DeviceUser":DeviceUser,
                                    "StartTime":start_time,
                                    "EndTime":end_time,
                                    "Desc":"Desc"
                                }),
                                success: function (data) {
                                    alert("设置成功！");
                                    TaskCode = data.TaskCode;
                                    flag = 1;
                                },
                                error: function (data) {
                                    alert("时间范围设置错误！")
                                    flag = 0;
                                }
                            });
                        }
                    }
                }
            }
        }
    })
})