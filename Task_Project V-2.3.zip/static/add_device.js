var UserName = localStorage.getItem('current_UserName');
var app = new Vue({
    el:'#audit',
    data:{
        UserName:UserName
    }
});
$(document).ready(function () {

    var role = localStorage.getItem('userRole');
    var DeviceUser = localStorage.getItem('current_UserCode');
    var DeviceOwnner = localStorage.getItem('UserCode');
    $('#add_btn').click(function(){
        var device_id = $("#device_id").val();
        var device_name = $("#device_name").val();
        var flag;
        $.ajax
        ({
            async:true,
            type: "POST",
            url: "http://47.102.42.105:8181/Device/addDeviceByIMEI",
            dataType: "json",
            data: JSON.stringify({
                "DeviceIMEI":device_id,
                "DeviceOwnner":DeviceOwnner,
                "DeviceUser": DeviceUser,
                "DeviceName":device_name
            }),
            contentType: "application/json",
            success: function (data) {
                flag = data.flag;
                if(flag == 1){
                    alert("添加成功！");
                }else{
                    alert("添加失败!");
                }
            },
            error:function (data) {
                alert("添加错误!");
                flag = 0;
            }
        });
    })
})