var CodeInfo;
var flag;
var NameInfo;
var RoleInfo;
var PhoneInfo;
var ProviceInfo;
var areaInfo;
var role;
var leaderCode = localStorage.getItem('leaderCode');
var UserCode = localStorage.getItem('UserCode');
RoleInfo = localStorage.getItem('userRole');
PhoneInfo = localStorage.getItem('userPhone');
NameInfo = localStorage.getItem('UserName');
ProviceInfo = localStorage.getItem('provinceInfo');
areaInfo = localStorage.getItem('areaInfo')
if(RoleInfo == 1){
    role = "用户";
    localStorage.setItem("role",role);
}else if(RoleInfo == 2){
    role = "管理员";
    localStorage.setItem("role",role);
}else{
    role = "超级管理员";
    localStorage.setItem("role",role);
}
var audit = new Vue({
    el:'#audit',
    data: {
        Phone: PhoneInfo,
        Name: NameInfo,
        ProvinceInfo:ProviceInfo,
        Area: areaInfo,
        role: role,
    }
})