$(document).ready(function(){
    var role = localStorage.getItem('userRole');
    if(role == 1){
        $('#1').hide();
        $('#2').hide();
        $('#4').hide();
        $('#5').hide();
    }
})