var UserName = localStorage.getItem('Device_UserName');
var app = new Vue({
    el:'#audit',
    data:{
        UserName:UserName
    }
});
$(document).ready(function(){
    var Telecom = localStorage.getItem('Telecom');
    var Device_Code = localStorage.getItem('DeviceCode');
    $.ajax({
        async: true,
        url: "http://47.102.42.105:8181/Device/getDeviceData",
        type: "POST",
        dataType: "json",
        data: JSON.stringify({
                "DianXinCodeList": [
                    {
                        "DianXinCode": Telecom
                    }
                ],
                "Length":1
            }
        ),
        contentType: "application/json",
        success: function (res) {
            var tr;
            for (i = 0; i < res.msg.length; i++) {
                tr = '<td id="Device_Code">' + Device_Code + '</td>' + '<td id="temp">' + res.msg[i].temp + '</td>' + '<td id="lock_staus">' + res.msg[i].lock_staus + '</td>'
                    + '<td id="mc_staus">' + res.msg[i].mc_staus + '</td>' + '<td id="updataTime">' + res.msg[i].updataTime + '</td>'
                    + '<td id="humi">' + res.msg[i].humi + '</td>' + '<td id="zhengdong">' + res.msg[i].zhengdong + '</td>'
                    + '<td id="deviceId">' + res.msg[i].deviceId + '</td>' + '<td id="dbm">' + res.msg[i].dbm + '</td>'+ '<td id="shuijing">' + res.msg[i].shuijing + '</td>'
                    + '<td id="voltage">' + res.msg[i].voltage + '</td>'
                $("#table").append('<tr id="current" style="height: 50px;">' + tr + '</tr>');
            }
        }
    })
})