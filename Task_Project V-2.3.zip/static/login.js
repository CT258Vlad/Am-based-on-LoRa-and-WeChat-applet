$(document).ready(function(){
    var url = "http://47.102.42.105:8181";
    // var url = "http://127.20.10.6:8181";
    var userCode;
    var token;
    var flag;
    var LoginNameInfo;
    var LoginPassordInfo;
    var provinceInfo;
    var userPhone;
    var UserProvince;
    var areaInfo;
    var userMail;
    var userRole;
    var description;
    var leaderCode;
    var userRole;
    $("#entry_btn").click(function(){
        $("#entry_btn").mouseenter(function(){
            $("#entry_btn").css("background-color","WhiteSmoke");
        });
        $("#entry_btn").mouseleave(function(){
            $("#entry_btn").css("background-color","lightgray");
        });
        LoginNameInfo=$("#username").val();
        LoginPassordInfo=$("#password").val();
        $.ajax
        ({
            async:true,
            type: "POST",
            url: url+"/User/UserLogin",
            dataType: "json",
            data: JSON.stringify({"LoginNameInfo":LoginNameInfo,"LoginPassordInfo":LoginPassordInfo}),
            contentType: "application/json",
            success: function (data) {
                userCode = data.userCode;
                token = data.token;
                flag = data.flag;
                provinceInfo = data.provinceInfo;
                description = data.description;
                areaInfo = data.areaInfo;
                userMail = data.userMail;
                userRole = data.userRole;
                UserProvince = data.UserProvince;
                userPhone = data.userPhone;
                localStorage.setItem('data',data);
                localStorage.setItem('UserCode',userCode);
                localStorage.setItem('UserName',LoginNameInfo);
                localStorage.setItem('userRole',userRole);
                localStorage.setItem('userMail',userMail);
                localStorage.setItem('userPhone',userPhone);
                localStorage.setItem('areaInfo',areaInfo);
                localStorage.setItem('provinceInfo',provinceInfo);
                localStorage.setItem('UserProvince',UserProvince);
                localStorage.setItem('leaderCode',userCode);
                var RoleInfo = localStorage.getItem('userRole');
                if(flag == 1){
                    alert("登录成功！");
                    if(RoleInfo == 1){
                        window.location.href="userFrame.html";
                    }else{
                        window.location.href="frame.html";
                    }
                }else{
                    alert("用户名或者密码错误!");
                }
            },
            error:function (data) {
                alert("账号或者密码错误!");
                flag = 0;
            }
        });
    });
});