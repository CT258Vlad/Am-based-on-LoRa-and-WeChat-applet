$(document).ready(function () {
    var LeaderCode = localStorage.getItem('UserCode');
    var LeaderName = localStorage.getItem('UserName');
    var ProvinceInfo = localStorage.getItem('provinceInfo');
    var AdminRole = localStorage.getItem('userRole');
    var UserProvince = localStorage.getItem('UserProvince');
    var Province;
    var i;var CityInfo;var UserProvince = localStorage.getItem('UserProvince');
    var ProvinceName; var CityName;
    var areaName;var areaCode;
    if(AdminRole == 2) {
        $("#Pro").hide();
    }
    $("#city_btn").click(function(){
        $("#city").empty();
        $.ajax({
            async: true,
            type: "GET",
            url: "http://47.102.42.105:8181/Area/getAreaInfo?provinceCode="+UserProvince,
            dataType: "json",
            contentType: "application/json",
            success: function (res) {
                for(i = 0;i<res.msg.length;i++){
                    $("#city").append("<option>"+res.msg[i].areaName+" : "+res.msg[i].areaCode+"</option>");
                    var form=layui.form;
                    form.render();
                }
            },
            error: function (data) {
                alert("当前用户不存在!");
                flag = 0;
            }
        });
    })
    if(AdminRole == 3){
        $('#role').append("<option>"+"管理员"+"</option>");
        $('#city_btn').hide();
        $.ajax({
            url:'../Area.json',
            async: true,
            dataType: "json",
            contentType: "application/json",
            success: function (data) {
                for(i = 0;i<data.length;i++){
                    $("#province").append("<option>"+data[i].provinceName+" : "+data[i].provinceCode+"</option>");
                }
            },
            error: function (data) {
                alert("当前用户不存在!");
                flag = 0;
            }
        });
    }
    $("#province").change(function(){
        Province = $('#province').val();
        var ProvinceArray = new Array();
        ProvinceArray=Province.split(' : ');
        for(var i=0;i<ProvinceArray.length;i++)
        {
            if(i==0){
                ProvinceName = ProvinceArray[0];
            }else if(i==1){
                ProvinceCode = ProvinceArray[1];
            }
        }
        localStorage.setItem('ProvinceCode',ProvinceCode);
    });
    $("#btn").click(function(){
        $("#province").change();
    })
    $("#btn").click(function() {
        ProvinceCode = localStorage.getItem('ProvinceCode');
        $("#city").empty();
        $.ajax({
            async: true,
            type: "GET",
            url: "http://47.102.42.105:8181/Area/getAreaInfo?provinceCode="+ProvinceCode,
            dataType: "json",
            contentType: "application/json",
            success: function (data) {
                for(i = 0;i<data.msg.length;i++){
                    $("#city").append("<option>"+data.msg[i].areaName+" : "+data.msg[i].areaCode+"</option>");
                    var form=layui.form;
                    form.render();
                }
            },
            error: function (data) {
                alert("当前用户不存在!");
                flag = 0;
            }
        });
    });
    ProvinceCode = localStorage.getItem('ProvinceCode');
    $("#register_btn").click(function () {
        var area = $("#city").val();
        var areaArray = new Array();
        areaArray=area.split(' : ');
        for(var i=0;i<areaArray.length;i++)
        {
            if(i==0){
                areaName = areaArray[0];
            }else if(i==1){
                areaCode = areaArray[1];
            }
        }
        localStorage.setItem('areaCode',areaCode);
        areaCode = localStorage.getItem('areaCode');
        var LoginName = $("#LoginName").val();
        var UserPwd = $("#LoginPwd").val();
        var UserName = $("#userName").val();
        var phone = $("#phone").val();
        var mail = $("#mail").val();
        var city = $("#city").val();
        var role = $('#role').val();
        var Description = $('#Description').val();
        var UserRole;Province = $("#province").val();
        if(role == "超级管理员"){
            UserRole = 3;
        }else if(role == "管理员"){
            UserRole = 2;
        }else if(role == "用户"){
            UserRole = 1;
        }
        if (UserName == null) {
            alert("用户名不能为空!");
        }else if (phone == null) {
            alert("手机不能为空!");
        }else if (mail == null) {
            alert("邮箱不能为空!");
        }else if(role == "请选择权限"){
            alert("权限不能为空");
        }else if (city == null){
            alert("地址不能为空");
        }else if(Description == null){
            alert("用户描述不能为空");
        }
        if(AdminRole==3){
            if((UserName!=null)&&(phone!=null)&&(mail!=null)&&(role!="请选择权限")&&(Province!="请选择省份")&&(areaCode!=null)&&(Description!=null)){
                $.ajax
                ({
                    async: true,
                    type: "POST",
                    url: "http://47.102.42.105:8181/User/AddUser",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify(
                        {
                            "LoginName":LoginName,
                            "LoginPassword":UserPwd,
                            "UserMail":mail,
                            "UserName":UserName,
                            "UserPhone":phone,
                            "Description":Description,
                            "ProvinceInfo":ProvinceCode,
                            "AreaInfo":area,
                            "UserRole":UserRole,
                            "LeaderCode":LeaderCode,
                            "Activity":true
                        }
                    ),
                    success: function (data) {
                        var flag = data.flag;
                        if(flag == 1){
                            alert(data.msg);
                        }else if(flag == 0) {
                            alert(data.msg);
                        }
                    },
                    error: function (data) {
                        alert("注册失败");
                    }
                });
            }
        }
        else if(AdminRole==2){
            if((UserName!=null)&&(phone!=null)&&(mail!=null)&&(role!="请选择权限")&&(city!="请选择城市")&&(Description!=null)){
                $.ajax
                ({
                    async: true,
                    type: "POST",
                    url: "http://47.102.42.105:8181/User/AddUser",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify(
                        {
                            "LoginName":LoginName,
                            "LoginPassword":UserPwd,
                            "UserMail":mail,
                            "UserName":UserName,
                            "UserPhone":phone,
                            "Description":Description,
                            "ProvinceInfo":UserProvince,
                            "AreaInfo":areaCode,
                            "UserRole":UserRole,
                            "LeaderCode":LeaderCode,
                            "Activity":true
                        }
                    ),
                    contentType: "application/json",
                    success: function (data) {
                        var flag = data.flag;
                        if(flag == 1){
                            alert(data.msg);
                        }else if(flag == 0) {
                            alert(data.msg);
                        }
                    },
                    error: function (data) {
                        alert("注册失败");
                    }
                });
            }
        }
    });
})