var count = 0;
var currentPage = 1;
var totalPage;
var i;
var url = "http://47.102.42.105:8181";
var LeaderName = localStorage.getItem("LoginNameInfo");
var UserCode = localStorage.getItem("UserCode");
$(document).ready(function() {
    var LeaderCode = localStorage.getItem("leaderCode");
    $("#fenye").html();
    var i;
    var ProvinceCode = localStorage.getItem('ProvinceCode');
    $.ajax({
        async: true,
        url: url+"/User/GetUserInfoForAdmin",
        type: "POST",
        dataType: "json",
        data: JSON.stringify({
                "UserName":"",
                "UserCode":"",
                "Page": currentPage,
                "Limit": 10,
                "LeaderCode": LeaderCode,
                "Activity": true
            }
        ),
        contentType: "application/json",
        success: function (res) {
            var tr;
            localStorage.setItem('page', res.page);
            totalPage = res.page;
            for (i = 0; i < res.msg.length; i++) {
                tr = '<td id="UserName">'+res.msg[i].UserName+'</td>'
                    +'<td id="Description">'+res.msg[i].Description+'</td>'+'<td id="LoginName">'+res.msg[i].LoginName+'</td>'
                    +'<td id="UserPhone">'+res.msg[i].UserPhone+'</td>'+'<td id="UserMail">' + res.msg[i].UserMail + '</td>'
                    +'<td id="ProvinceInfo">'+res.msg[i].ProvinceInfo+'</td>'+'<td id="AreaInfo">'+res.msg[i].AreaInfo+'</td>'
                    +'<td id="Activity">'+res.msg[i].Activity+'</td>'
                    +'<td id="pwd"></td>'+'<td id="td"><p id="UserCode">'+res.msg[i].UserCode+'</p><button class="modify"> 修改 </button>&nbsp;<button class="add_task"> 添加设备 </button>&nbsp;<button class="remove"> 删除 </button><p id="role">'+res.msg[i].UserRole+'</p><a id="areaCode">'+ res.msg[i].UserArea +'</a></td>'
                $("#table").append('<tr id="current" style="height: 50px;">' + tr + '</tr>');
                $(".modify").siblings("#role").hide();
                $(".modify").siblings("#areaCode").hide();
                $(".modify").siblings("#UserCode").hide();
            }
            $(".add_task").click(function () {
                var current_UserName = $(this).parent().siblings("#UserName").text();
                var current_UserCode = $(this).parent().siblings("#UserCode").text();
                localStorage.setItem('current_UserName',current_UserName);
                localStorage.setItem('current_UserCode',current_UserCode);
                window.location.href="../admin/add_device.html";
            });
            $(".modify").click(function () {
                $(this).parent().siblings("td").each(function ()//找同类元素td
                {
                    var is_text = $(this).find("input:text");//判断单元格下是否含有文本框
                    if (!is_text.length) {
                        $(this).html("<input size='13' style='width: 180px' type='text' value='"+$(this).text()+"'/>");
                    }
                    else
                        $(this).html(is_text.val());
                })
                $(".modify").click(function () {
                    var UserName = $(this).parent().siblings("#UserName").text();
                    var UserCode = $(this).parent().siblings("#UserCode").text();
                    var Description = $(this).parent().siblings("#Description").text();
                    var UserPhone = $(this).parent().siblings("#UserPhone").text();
                    var UserMail = $(this).parent().siblings("#UserMail").text();
                    var ProvinceInfo = $(this).parent().siblings("#ProvinceInfo").text();
                    var AreaInfo = $(this).parent().siblings("#AreaInfo").text();
                    var Activity = $(this).parent().siblings("#Activity").text();
                    var pwd = $(this).parent().siblings("#pwd").text();
                    var RoleInfo = $(this).siblings("#role").text();
                    var UserArea = $(this).siblings("#areaCode").text();
                    var LoginName = $(this).parent().siblings("#LoginName").text();
                    $.ajax({
                        async: true,
                        url: url+"/User/UpdateUserInfo",
                        type: "POST",
                        dataType: "json",
                        contentType: "application/json",
                        data: JSON.stringify({
                            "LoginName":LoginName,
                            "LoginPassword":pwd,
                            "UserMail":UserMail,
                            "UserName":UserName,
                            "UserPhone":UserPhone,
                            "Description":Description,
                            "UserArea":UserArea,
                            "Activity":true,
                            "UserCode":UserCode
                        }),
                        success: function (data) {
                            var flag = data.flag;
                            if (flag == 1) {
                                alert("修改成功！");
                            } else {
                                alert("修改失败！");
                            }
                        },
                        error: function (data) {
                            alert("修改失败!");
                            flag = 0;
                        }
                    })
                })
            });
            $(".remove").click(function () {
                var UserCode = $(this).parent().siblings("#UserCode").text();
                if (window.confirm("您确定要删除数据吗?")) {
                    $(this).parent().parent().remove();
                    $.ajax({
                        async: true,
                        url: url+"/User/DeleteUserInfo",
                        type: "POST",
                        dataType: "json",
                        contentType: "application/json",
                        data: JSON.stringify({
                            "UserCode":UserCode
                        }),
                        success: function (data) {
                            var flag = data.flag;
                            if (flag == 1) {
                                alert("删除成功！");
                            } else {
                                alert("删除失败！");
                            }
                        },
                        error: function (data) {
                            alert("删除失败!");
                            flag = 0;
                        }
                    })
                }
            });
        }
    });

    totalPage = localStorage.getItem('page');

    $('#add').click(function () {
        if(currentPage == totalPage){
            alert("已经是最后一页了");
        }else {
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            if (currentPage < totalPage) {
                currentPage++;
                $.ajax({
                    async: true,
                    url: url+"/User/GetUserInfoForAdmin",
                    type: "POST",
                    dataType: "json",
                    data: JSON.stringify({
                            "UserName":"",
                            "UserCode":"",
                            "Page": currentPage,
                            "Limit": 10,
                            "LeaderCode": LeaderCode,
                            "Activity": true
                        }
                    ),
                    contentType: "application/json",
                    success: function (res) {
                        var tr;
                        localStorage.setItem('page', res.page);
                        totalPage = res.page;
                        for (i = 0; i < res.msg.length; i++) {
                            tr = '<td id="UserName">'+res.msg[i].UserName+'</td>'
                                +'<td id="Description">'+res.msg[i].Description+'</td>'+'<td id="LoginName">'+res.msg[i].LoginName+'</td>'
                                +'<td id="UserPhone">'+res.msg[i].UserPhone+'</td>'+'<td id="UserMail">' + res.msg[i].UserMail + '</td>'
                                +'<td id="ProvinceInfo">'+res.msg[i].ProvinceInfo+'</td>'+'<td id="AreaInfo">'+res.msg[i].AreaInfo+'</td>'
                                +'<td id="Activity">'+res.msg[i].Activity+'</td>'
                                +'<td id="pwd"></td>'+'<td id="td"><p id="UserCode">'+res.msg[i].UserCode+'</p><button class="modify"> 修改 </button>&nbsp;<button class="add_task"> 添加设备 </button>&nbsp;<button class="remove"> 删除 </button><p id="role">'+res.msg[i].UserRole+'</p><a id="areaCode">'+ res.msg[i].UserArea +'</a></td>'
                            $("#table").append('<tr id="current" style="height: 50px;">' + tr + '</tr>');
                            $(".modify").siblings("#role").hide();
                            $(".modify").siblings("#areaCode").hide();
                            $(".modify").siblings("#UserCode").hide();
                        }
                        $(".add_task").click(function () {
                            var current_UserName = $(this).parent().siblings("#UserName").text();
                            var current_UserCode = $(this).parent().siblings("#UserCode").text();
                            localStorage.setItem('current_UserName',current_UserName);
                            localStorage.setItem('current_UserCode',current_UserCode);
                            window.location.href="../admin/add_device.html";
                        });
                        $(".modify").click(function () {
                            $(this).parent().siblings("td").each(function ()//找同类元素td
                            {
                                var is_text = $(this).find("input:text");//判断单元格下是否含有文本框
                                if (!is_text.length) {
                                    $(this).html("<input size='13' style='width: 180px' type='text' value='"+$(this).text()+"'/>");
                                }
                                else
                                    $(this).html(is_text.val());
                            })
                            $(".modify").click(function () {
                                var UserName = $(this).parent().siblings("#UserName").text();
                                var UserCode = $(this).parent().siblings("#UserCode").text();
                                var Description = $(this).parent().siblings("#Description").text();
                                var UserPhone = $(this).parent().siblings("#UserPhone").text();
                                var UserMail = $(this).parent().siblings("#UserMail").text();
                                var ProvinceInfo = $(this).parent().siblings("#ProvinceInfo").text();
                                var AreaInfo = $(this).parent().siblings("#AreaInfo").text();
                                var Activity = $(this).parent().siblings("#Activity").text();
                                var pwd = $(this).parent().siblings("#pwd").text();
                                var RoleInfo = $(this).siblings("#role").text();
                                var UserArea = $(this).siblings("#areaCode").text();
                                var LoginName = $(this).parent().siblings("#LoginName").text();
                                $.ajax({
                                    async: true,
                                    url: url+"/User/UpdateUserInfo",
                                    type: "POST",
                                    dataType: "json",
                                    contentType: "application/json",
                                    data: JSON.stringify({
                                        "LoginName":LoginName,
                                        "LoginPassword":pwd,
                                        "UserMail":UserMail,
                                        "UserName":UserName,
                                        "UserPhone":UserPhone,
                                        "Description":Description,
                                        "UserArea":UserArea,
                                        "Activity":true,
                                        "UserCode":UserCode
                                    }),
                                    success: function (data) {
                                        var flag = data.flag;
                                        if (flag == 1) {
                                            alert("修改成功！");
                                        } else {
                                            alert("修改失败！");
                                        }
                                    },
                                    error: function (data) {
                                        alert("修改失败!");
                                        flag = 0;
                                    }
                                })
                            })
                        });
                        $(".remove").click(function () {
                            var UserCode = $(this).parent().siblings("#UserCode").text();
                            if (window.confirm("您确定要删除数据吗?")) {
                                $(this).parent().parent().remove();
                                $.ajax({
                                    async: true,
                                    url: url+"/User/DeleteUserInfo",
                                    type: "POST",
                                    dataType: "json",
                                    contentType: "application/json",
                                    data: JSON.stringify({
                                        "UserCode":UserCode
                                    }),
                                    success: function (data) {
                                        var flag = data.flag;
                                        if (flag == 1) {
                                            alert("删除成功！");
                                        } else {
                                            alert("删除失败！");
                                        }
                                    },
                                    error: function (data) {
                                        alert("删除失败!");
                                        flag = 0;
                                    }
                                })
                            }
                        });
                    }
                });
            }
        }
    })
    $('#cut').click(function () {
        $("#current").remove();
        $("#current").remove();
        $("#current").remove();
        $("#current").remove();
        $("#current").remove();
        $("#current").remove();
        $("#current").remove();
        $("#current").remove();
        $("#current").remove();
        $("#current").remove();
        currentPage--;
        $.ajax({
            async: true,
            url: url+"/User/GetUserInfoForAdmin",
            type: "POST",
            dataType: "json",
            data: JSON.stringify({
                    "UserName":"",
                    "UserCode":"",
                    "Page": currentPage,
                    "Limit": 10,
                    "LeaderCode": LeaderCode,
                    "Activity": true
                }
            ),
            contentType: "application/json",
            success: function (res) {
                var tr;
                localStorage.setItem('page', res.page);
                totalPage = res.page;
                for (i = 0; i < res.msg.length; i++) {
                    tr = '<td id="UserName">'+res.msg[i].UserName+'</td>'
                        +'<td id="Description">'+res.msg[i].Description+'</td>'+'<td id="LoginName">'+res.msg[i].LoginName+'</td>'
                        +'<td id="UserPhone">'+res.msg[i].UserPhone+'</td>'+'<td id="UserMail">' + res.msg[i].UserMail + '</td>'
                        +'<td id="ProvinceInfo">'+res.msg[i].ProvinceInfo+'</td>'+'<td id="AreaInfo">'+res.msg[i].AreaInfo+'</td>'
                        +'<td id="Activity">'+res.msg[i].Activity+'</td>'
                        +'<td id="pwd"></td>'+'<td id="td"><p id="UserCode">'+res.msg[i].UserCode+'</p><button class="modify"> 修改 </button>&nbsp;<button class="add_task"> 添加设备 </button>&nbsp;<button class="remove"> 删除 </button><p id="role">'+res.msg[i].UserRole+'</p><a id="areaCode">'+ res.msg[i].UserArea +'</a></td>'
                    $("#table").append('<tr id="current" style="height: 50px;">' + tr + '</tr>');
                    $(".modify").siblings("#role").hide();
                    $(".modify").siblings("#areaCode").hide();
                    $(".modify").siblings("#UserCode").hide();
                }
                $(".add_task").click(function () {
                    var current_UserName = $(this).parent().siblings("#UserName").text();
                    var current_UserCode = $(this).parent().siblings("#UserCode").text();
                    localStorage.setItem('current_UserName',current_UserName);
                    localStorage.setItem('current_UserCode',current_UserCode);
                    window.location.href="../admin/add_device.html";
                });
                $(".modify").click(function () {
                    $(this).parent().siblings("td").each(function ()//找同类元素td
                    {
                        var is_text = $(this).find("input:text");//判断单元格下是否含有文本框
                        if (!is_text.length) {
                            $(this).html("<input size='13' style='width: 180px' type='text' value='"+$(this).text()+"'/>");
                        }
                        else
                            $(this).html(is_text.val());
                    })
                    $(".modify").click(function () {
                        var UserName = $(this).parent().siblings("#UserName").text();
                        var UserCode = $(this).parent().siblings("#UserCode").text();
                        var Description = $(this).parent().siblings("#Description").text();
                        var UserPhone = $(this).parent().siblings("#UserPhone").text();
                        var UserMail = $(this).parent().siblings("#UserMail").text();
                        var ProvinceInfo = $(this).parent().siblings("#ProvinceInfo").text();
                        var AreaInfo = $(this).parent().siblings("#AreaInfo").text();
                        var Activity = $(this).parent().siblings("#Activity").text();
                        var pwd = $(this).parent().siblings("#pwd").text();
                        var RoleInfo = $(this).siblings("#role").text();
                        var UserArea = $(this).siblings("#areaCode").text();
                        var LoginName = $(this).parent().siblings("#LoginName").text();
                        $.ajax({
                            async: true,
                            url: url+"/User/UpdateUserInfo",
                            type: "POST",
                            dataType: "json",
                            contentType: "application/json",
                            data: JSON.stringify({
                                "LoginName":LoginName,
                                "LoginPassword":pwd,
                                "UserMail":UserMail,
                                "UserName":UserName,
                                "UserPhone":UserPhone,
                                "Description":Description,
                                "UserArea":UserArea,
                                "Activity":true,
                                "UserCode":UserCode
                            }),
                            success: function (data) {
                                var flag = data.flag;
                                if (flag == 1) {
                                    alert("修改成功！");
                                } else {
                                    alert("修改失败！");
                                }
                            },
                            error: function (data) {
                                alert("修改失败!");
                                flag = 0;
                            }
                        })
                    })
                });
                $(".remove").click(function () {
                    var UserCode = $(this).parent().siblings("#UserCode").text();
                    if (window.confirm("您确定要删除数据吗?")) {
                        $(this).parent().parent().remove();
                        $.ajax({
                            async: true,
                            url: url+"/User/DeleteUserInfo",
                            type: "POST",
                            dataType: "json",
                            contentType: "application/json",
                            data: JSON.stringify({
                                "UserCode":UserCode
                            }),
                            success: function (data) {
                                var flag = data.flag;
                                if (flag == 1) {
                                    alert("删除成功！");
                                } else {
                                    alert("删除失败！");
                                }
                            },
                            error: function (data) {
                                alert("删除失败!");
                                flag = 0;
                            }
                        })
                    }
                });
            }
        });
    })
});
totalPage = localStorage.getItem('page');
var audit = new Vue({
    el: '#audit',
    data(){
        return{
            currentPage:0,
            Page: totalPage,
            count : 0,
        };
    },
    methods: {
        turnPage(num) {
            if (num == 1) {
                if (this.currentPage === this.totalPage - 1) {
                    return
                } else {
                    if(this.currentPage<totalPage){
                        this.currentPage++
                    }
                }
            } else {
                if (this.currentPage === 0) {
                    return
                } else {
                    if(this.currentPage>0){
                        this.currentPage--
                    }
                }
            }
        },
    }
})