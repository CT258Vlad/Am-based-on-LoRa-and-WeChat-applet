var count = 0;
var currentPage = 1;
var totalPage;
var i;
$(document).ready(function(){
    $("#fenye").html();
    var i;
    var UserCode= localStorage.getItem('UserCode');
    $.ajax({
        async:true,
        url:"http://47.102.42.105:8181/Device/getDeviceByUserCode",
        type:"POST",
        dataType:"json",
        data: JSON.stringify({
                "UserCode": localStorage.getItem('UserCode'),
                "Page":currentPage,
                "Limit":5,
            }
        ),
        contentType: "application/json",
        success:function(res){
            var DeviceCode = res.msg.DeviceCode;
            var DeviceIMEI = res.msg.DeviceIMEI;
            var DeviceName = res.msg.DeviceName;
            var UserName = res.msg.UserName;
            var DeviceUser = res.msg.DeviceUser;
            var tr;
            totalPage = res.msg.page;
            localStorage.setItem('page',res.page);
            totalPage = res.page;
            for (i = 0 ;i<res.msg.length;i++){
                tr= '<td id="DeviceCode">'+res.msg[i].DeviceCode+'</td>'+'<td id="DeviceIMEI">'+res.msg[i].DeviceIMEI+'</td>'+'<td id="DeviceName">'+res.msg[i].DeviceName+'</td>'+
                    '<td id="UserName">'+res.msg[i].UserName+'</td>'+'<td id="OwnnerName">'+res.msg[i].OwnnerName+'</td>'+
                    '<td><button class="button">添加任务</button><button class="check">设备信息</button><p id="DeviceUser">'+res.msg[i].DeviceUser+'</p><p id="Telecom">'+res.msg[i].DianXinCode+'</p><p id="DeviceOwnner">'+res.msg[i].DeviceOwnner+'</p></td>'
                $("#table").append('<tr id="current" style="height: 50px;">'+tr+'</tr>');
                $(".button").siblings("#Telecom").hide();
                $(".button").siblings("#DeviceOwnner").hide();
                $(".button").siblings("#DeviceUser").hide();
            };
            $(".button").click(function(){
                var Device_IMEI = $(this).parent().siblings("#DeviceIMEI").text();
                var DeviceUser = $(this).parent().siblings("#DeviceUser").text();
                var DeviceCode = $(this).parent().siblings("#DeviceCode").text();
                var DeviceOwnner = $(this).siblings("#DeviceOwnner").text();
                localStorage.setItem('DeviceOwnner',DeviceOwnner);
                localStorage.setItem('DeviceUser',DeviceUser);
                localStorage.setItem('DeviceCode',DeviceCode);
                window.location.href="../admin/task.html";
            })
            $(".check").click(function(){
                var Telecom = $(this).siblings("#Telecom").text();
                var UserName = $(this).parent().siblings("#UserName").text();
                var DeviceCode = $(this).parent().siblings("#DeviceCode").text();
                localStorage.setItem('DeviceCode',DeviceCode);
                localStorage.setItem('Device_UserName',UserName);
                localStorage.setItem('Telecom',Telecom);
                window.location.href="../admin/device_Info.html";
            })
        }
    });
    totalPage = localStorage.getItem('page');
    $('#add').click(function(){
        if(currentPage == totalPage){
            alert("已经是最后一页了")
        }
        else{
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            if(currentPage < totalPage){
                currentPage ++;
                $.ajax({
                    async:true,
                    url:"http://47.102.42.105:8181/Device/getDeviceByUserCode",
                    type:"POST",
                    dataType:"json",
                    data: JSON.stringify({
                            "DeviceOwnner": UserCode,
                            "Page":currentPage,
                            "Limit":5,
                        }
                    ),
                    contentType: "application/json",
                    success:function(res){
                        var DeviceCode = res.msg.DeviceCode;
                        var DeviceIMEI = res.msg.DeviceIMEI;
                        var DeviceName = res.msg.DeviceName;
                        var UserName = res.msg.UserName;
                        var DeviceUser = res.msg.DeviceUser;
                        var tr;
                        totalPage = res.msg.page;
                        localStorage.setItem('page',res.page);
                        totalPage = res.page;
                        for (i = 0 ;i<res.msg.length;i++){
                            tr= '<td id="DeviceCode">'+res.msg[i].DeviceCode+'</td>'+'<td id="DeviceIMEI">'+res.msg[i].DeviceIMEI+'</td>'+'<td id="DeviceName">'+res.msg[i].DeviceName+'</td>'+
                                '<td id="UserName">'+res.msg[i].UserName+'</td>'+'<td id="OwnnerName">'+res.msg[i].OwnnerName+'</td>'+
                                '<td><button class="button">添加任务</button><button class="check">设备信息</button><p id="DeviceUser">'+res.msg[i].DeviceUser+'</p><p id="Telecom">'+res.msg[i].DianXinCode+'</p><p id="DeviceOwnner">'+res.msg[i].DeviceOwnner+'</p></td>'
                            $("#table").append('<tr id="current" style="height: 50px;">'+tr+'</tr>');
                            $(".button").siblings("#Telecom").hide();
                            $(".button").siblings("#DeviceOwnner").hide();
                            $(".button").siblings("#DeviceUser").hide();
                        };
                        $(".button").click(function(){
                            var Device_IMEI = $(this).parent().siblings("#DeviceIMEI").text();
                            var DeviceUser = $(this).parent().siblings("#DeviceUser").text();
                            var DeviceCode = $(this).parent().siblings("#DeviceCode").text();
                            var DeviceOwnner = $(this).parent().siblings("#DeviceOwnner").text();
                            localStorage.setItem('DeviceOwnner',DeviceOwnner);
                            localStorage.setItem('DeviceUser',DeviceUser);
                            localStorage.setItem('DeviceCode',DeviceCode);
                            window.location.href="../admin/task.html";
                        })
                        $(".check").click(function(){
                            var Telecom = $(this).siblings("#Telecom").text();
                            var DeviceUser = $(this).parent().siblings("#DeviceUser").text();
                            var DeviceCode = $(this).parent().siblings("#DeviceCode").text();
                            localStorage.setItem('DeviceCode',DeviceCode);
                            localStorage.setItem('Device_UserName',UserName);
                            localStorage.setItem('Telecom',Telecom);
                            window.location.href="../admin/device_Info.html";
                        })
                    }
                });
            }
        }
    })
    $('#cut').click(function(){
        if(currentPage == 1){
            alert("已经是第一页了！");
        }else{
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            currentPage --;
            $.ajax({
                async:true,
                url:"http://47.102.42.105:8181/Device/getDeviceByUserCode",
                type:"POST",
                dataType:"json",
                data: JSON.stringify({
                        "DeviceOwnner": UserCode,
                        "Page":currentPage,
                        "Limit":5,
                    }
                ),
                contentType: "application/json",
                success:function(res){
                    var DeviceCode = res.msg.DeviceCode;
                    var DeviceIMEI = res.msg.DeviceIMEI;
                    var DeviceName = res.msg.DeviceName;
                    var UserName = res.msg.UserName;
                    var DeviceUser = res.msg.DeviceUser;
                    var tr;
                    totalPage = res.msg.page;
                    localStorage.setItem('page',res.page);
                    totalPage = res.page;
                    for (i = 0 ;i<res.msg.length;i++){
                        tr= '<td id="DeviceCode">'+res.msg[i].DeviceCode+'</td>'+'<td id="DeviceIMEI">'+res.msg[i].DeviceIMEI+'</td>'+'<td id="DeviceName">'+res.msg[i].DeviceName+'</td>'+
                            '<td id="UserName">'+res.msg[i].UserName+'</td>'+'<td id="OwnnerName">'+res.msg[i].OwnnerName+'</td>'+
                            '<td><button class="button">添加任务</button><button class="check">设备信息</button><p id="DeviceUser">'+res.msg[i].DeviceUser+'</p><p id="Telecom">'+res.msg[i].DianXinCode+'</p><p id="DeviceOwnner">'+res.msg[i].DeviceOwnner+'</p></td>'
                        $("#table").append('<tr id="current" style="height: 50px;">'+tr+'</tr>');
                        $(".button").siblings("#Telecom").hide();
                        $(".button").siblings("#DeviceOwnner").hide();
                        $(".button").siblings("#DeviceUser").hide();
                    };
                    $(".button").click(function(){
                        var Device_IMEI = $(this).parent().siblings("#DeviceIMEI").text();
                        var DeviceUser = $(this).parent().siblings("#DeviceUser").text();
                        var DeviceCode = $(this).parent().siblings("#DeviceCode").text();
                        var DeviceOwnner = $(this).parent().siblings("#DeviceOwnner").text();
                        localStorage.setItem('DeviceOwnner',DeviceOwnner);
                        localStorage.setItem('DeviceUser',DeviceUser);
                        localStorage.setItem('DeviceCode',DeviceCode);
                        window.location.href="../admin/task.html";
                    })
                    $(".check").click(function(){
                        var Telecom = $(this).siblings("#Telecom").text();
                        var UserName = $(this).parent().siblings("#UserName").text();
                        var DeviceCode = $(this).parent().siblings("#DeviceCode").text();
                        localStorage.setItem('DeviceCode',DeviceCode);
                        localStorage.setItem('Device_UserName',UserName);
                        localStorage.setItem('Telecom',Telecom);
                        window.location.href="../admin/device_Info.html";
                    })
                }
            });
        }
    })
});

totalPage = localStorage.getItem('page');
var audit = new Vue({
    el: '#audit',
    data(){
        return{
            currentPage:0,
            Page: totalPage,
            count : 0,
        };
    },
    methods: {
        turnPage(num) {
            if (num == 1) {
                if (this.currentPage == this.totalPage - 1) {
                    return
                } else {
                    if(this.currentPage<totalPage){
                        this.currentPage++
                    }
                }
            } else {
                if (this.currentPage == 0) {
                    return
                } else {
                    if(this.currentPage>0){
                        this.currentPage--
                    }
                }
            }
        },
    }
})