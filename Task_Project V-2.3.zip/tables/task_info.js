var count = 0;
var currentPage = 1;
var totalPage;var task_status;
var i;var Activity;
var UserCode = localStorage.getItem("UserCode");
$(document).ready(function(){
    $("#fenye").html();
    var i;
    var UserCode= localStorage.getItem('UserCode');
    $.ajax({
        async:true,
        url:"http://47.102.42.105:8181/Task/GetEffectiveTask",
        type:"POST",
        dataType:"json",
        data: JSON.stringify({
                "UserCode": UserCode,
                "status":"",
                "Page":currentPage,
                "Limit":5,
            }
        ),
        contentType: "application/json",
        success:function(data){
            var tr;
            totalPage = data.pages;
            localStorage.setItem('page',totalPage);
            for (i = 0 ;i<data.msg.length;i++){
                if(data.msg[i].Activity == "1"){
                    Activity = "已授权";
                }else{
                    Activity = "未授权";
                }
                if(data.msg[i].Status == "1"){
                    task_status = "可使用";
                }else if(data.msg[i].Status == "2"){
                    task_status = "已过期";
                }else{
                    task_status = "未开始";
                }
                var timestamp1 = data.msg[i].StartTime;
                var d1 = new Date(timestamp1 * 1000);
                var date1 = (d1.getFullYear()) + "-" + (d1.getMonth() + 1) + "-" + (d1.getDate()) + "  " + (d1.getHours()) + ":" + (d1.getMinutes()) + ":" + (d1.getSeconds());
                var timestamp2 = data.msg[i].EndTime;
                var d2 = new Date(timestamp2 * 1000);
                var date2 = (d2.getFullYear()) + "-" + (d2.getMonth() + 1) + "-" + (d2.getDate()) + "  " + (d2.getHours()) + ":" + (d2.getMinutes()) + ":" + (d2.getSeconds());
                tr='<td id="TaskCode">'+data.msg[i].TaskCode+'</td>'+'<td id="DeviceCode">'+data.msg[i].DeviceCode+'</td>'+'<td id="status">'+task_status+'</td>'+
                    '<td id="DeviceUser">'+data.msg[i].DeviceName+'</td>'+'<td id="StartTime">'+date1+'</td>'+'<td id="EndTime">'+date2+'</td>'+'<td id="Description">'+data.msg[i].Description+'</td>'
                    +'<td id="Activity">'+Activity+'</td>'+'<td width="4%"><button class="execute">执行任务</button></td>'
                $("#table").append('<tr id="current" style="height: 50px;">'+tr+'</tr>');
            }
            $(".execute").click(function(){
                var TaskCode = $(this).parent().siblings("#TaskCode").text();
                var DeviceCode = $(this).parent().siblings("#DeviceCode").text();
                var DeviceOwnner = $(this).parent().siblings("#DeviceOwnner").text();
                $.ajax({
                    async:true,
                    url:"http://47.102.42.105:8181/Task/ActiveTheUnlockTask",
                    type:"POST",
                    dataType:"json",
                    contentType: "application/json",
                    data: JSON.stringify({
                            "TaskCode":TaskCode,
                            "DeviceCode":DeviceCode,
                            "UserCode":UserCode,
                            "DeviceOwnner":DeviceOwnner
                        }
                    ),
                    success:function(data) {
                        console.log(data);
                        var flag = data.flag;
                        if(flag == 1){
                            alert("执行下发成功,任务记录已保存");
                        }else {
                            alert("该任务已丢失,请刷新")
                        }
                    },
                    error:function (data) {
                        alert("该任务已丢失,请刷新");
                        flag = 0;
                    }
                });
            })
        }
    });
    totalPage = localStorage.getItem('page');
    $('#add').click(function(){
        if(currentPage == totalPage){
            alert("已经是最后一页了")
        }
        else{
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            if(currentPage < totalPage){
                currentPage ++;
                $.ajax({
                    async:true,
                    url:"http://47.102.42.105:8181/Task/GetEffectiveTask",
                    type:"POST",
                    dataType:"json",
                    data: JSON.stringify({
                            "UserCode": UserCode,
                            "status":"",
                            "Page":currentPage,
                            "Limit":5,
                        }
                    ),
                    contentType: "application/json",
                    success:function(data){
                        var tr;
                        totalPage = data.pages;
                        for (i = 0 ;i<data.msg.length;i++){
                            if(data.msg[i].Activity == "1"){
                                Activity = "已授权";
                            }else{
                                Activity = "未授权";
                            }
                            if(data.msg[i].Status == "1"){
                                task_status = "可使用";
                            }else if(data.msg[i].Status == "2"){
                                task_status = "已过期";
                            }else{
                                task_status = "未开始";
                            }
                            var timestamp1 = data.msg[i].StartTime;
                            var d1 = new Date(timestamp1 * 1000);
                            var date1 = (d1.getFullYear()) + "-" + (d1.getMonth() + 1) + "-" + (d1.getDate()) + "  " + (d1.getHours()) + ":" + (d1.getMinutes()) + ":" + (d1.getSeconds());
                            var timestamp2 = data.msg[i].EndTime;
                            var d2 = new Date(timestamp2 * 1000);
                            var date2 = (d2.getFullYear()) + "-" + (d2.getMonth() + 1) + "-" + (d2.getDate()) + "  " + (d2.getHours()) + ":" + (d2.getMinutes()) + ":" + (d2.getSeconds());
                            tr='<td id="TaskCode">'+data.msg[i].TaskCode+'</td>'+'<td id="DeviceCode">'+data.msg[i].DeviceCode+'</td>'+'<td id="status">'+task_status+'</td>'+
                                '<td id="DeviceUser">'+data.msg[i].DeviceName+'</td>' +'<td id="StartTime">'+date1+'</td>'+'<td id="EndTime">'+date2+'</td>'+'<td id="Description">'+data.msg[i].Description+'</td>'
                                +'<td id="Activity">'+Activity+'</td>'+'<td width="4%"><button class="execute">执行任务</button></td>'
                            $("#table").append('<tr id="current" style="height: 50px;">'+tr+'</tr>');
                        }
                        $(".execute").click(function(){
                            var TaskCode = $(this).parent().siblings("#TaskCode").text();
                            var DeviceCode = $(this).parent().siblings("#DeviceCode").text();
                            var DeviceOwnner = $(this).parent().siblings("#DeviceOwnner").text();
                            $.ajax({
                                async:true,
                                url:"http://47.102.42.105:8181/Task/ActiveTheUnlockTask",
                                type:"POST",
                                dataType:"json",
                                contentType: "application/json",
                                data: JSON.stringify({
                                        "TaskCode":TaskCode,
                                        "DeviceCode":DeviceCode,
                                        "UserCode":UserCode,
                                        "DeviceOwnner":DeviceOwnner
                                    }
                                ),
                                success:function(data) {
                                    console.log(data);
                                    var flag = data.flag;
                                    if(flag == 1){
                                        alert("执行下发成功,任务记录已保存");
                                    }else {
                                        alert("该任务已丢失,请刷新")
                                    }
                                },
                                error:function (data) {
                                    alert("该任务已丢失,请刷新");
                                    flag = 0;
                                }
                            });
                        })
                    }
                });
            }
        }
    })
    $('#cut').click(function(){
        if(currentPage == 1){
            alert("已经是第一页了！");
        }else{
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            currentPage --;
            $.ajax({
                async:true,
                url:"http://47.102.42.105:8181/Task/GetEffectiveTask",
                type:"POST",
                dataType:"json",
                data: JSON.stringify({
                        "UserCode": UserCode,
                        "status":"",
                        "Page":currentPage,
                        "Limit":5,
                    }
                ),
                contentType: "application/json",
                success:function(data){
                    var tr;
                    totalPage = data.pages;
                    for (i = 0 ;i<data.msg.length;i++){
                        if(data.msg[i].Activity == "1"){
                            Activity = "已授权";
                        }else{
                            Activity = "未授权";
                        }
                        if(data.msg[i].Status == "1"){
                            task_status = "可使用";
                        }else if(data.msg[i].Status == "2"){
                            task_status = "已过期";
                        }else{
                            task_status = "未开始";
                        }
                        var timestamp1 = data.msg[i].StartTime;
                        var d1 = new Date(timestamp1 * 1000);
                        var date1 = (d1.getFullYear()) + "-" + (d1.getMonth() + 1) + "-" + (d1.getDate()) + "  " + (d1.getHours()) + ":" + (d1.getMinutes()) + ":" + (d1.getSeconds());
                        var timestamp2 = data.msg[i].EndTime;
                        var d2 = new Date(timestamp2 * 1000);
                        var date2 = (d2.getFullYear()) + "-" + (d2.getMonth() + 1) + "-" + (d2.getDate()) + "  " + (d2.getHours()) + ":" + (d2.getMinutes()) + ":" + (d2.getSeconds());
                        tr='<td id="TaskCode">'+data.msg[i].TaskCode+'</td>'+'<td id="DeviceCode">'+data.msg[i].DeviceCode+'</td>'+'<td id="status">'+task_status+'</td>'+
                            '<td id="DeviceUser">'+data.msg[i].DeviceName+'</td>' +'<td id="StartTime">'+date1+'</td>'+'<td id="EndTime">'+date2+'</td>'+
                            '<td id="Description">'+data.msg[i].Description+'</td>' +'<td id="Activity">'+Activity+'</td>'+'<td width="4%"><button class="execute">执行任务</button></td>'
                        $("#table").append('<tr id="current" style="height: 50px;">'+tr+'</tr>');
                    }
                    $(".execute").click(function(){
                        var TaskCode = $(this).parent().siblings("#TaskCode").text();
                        var DeviceCode = $(this).parent().siblings("#DeviceCode").text();
                        var DeviceOwnner = $(this).parent().siblings("#DeviceOwnner").text();
                        $.ajax({
                            async:true,
                            url:"http://47.102.42.105:8181/Task/ActiveTheUnlockTask",
                            type:"POST",
                            dataType:"json",
                            contentType: "application/json",
                            data: JSON.stringify({
                                    "TaskCode":TaskCode,
                                    "DeviceCode":DeviceCode,
                                    "UserCode":UserCode,
                                    "DeviceOwnner":DeviceOwnner
                                }
                            ),
                            success:function(data) {
                                var flag = data.flag;
                                if(flag == 1){
                                    alert("执行下发成功,任务记录已保存");
                                }else {
                                    alert("该任务已丢失,请刷新")
                                }
                            },
                            error:function (data) {
                                alert("该任务已丢失,请刷新");
                                flag = 0;
                            }
                        });
                    })
                }
            });
        }
    })
});
totalPage = localStorage.getItem('page');
var audit = new Vue({
    el: '#audit',
    data(){
        return{
            currentPage:0,
            Page: totalPage,
            count : 0,
        };
    },
    methods: {
        turnPage(num) {
            if (num == 1) {
                if (this.currentPage == this.totalPage - 1) {
                    return
                } else {
                    if(this.currentPage<totalPage){
                        this.currentPage++
                    }
                }
            } else {
                if (this.currentPage == 0) {
                    return
                } else {
                    if(this.currentPage>0){
                        this.currentPage--
                    }
                }
            }
        },
    }
})