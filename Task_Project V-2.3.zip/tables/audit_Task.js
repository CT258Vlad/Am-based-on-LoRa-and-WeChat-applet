var count = 0;
var currentPage = 1;
var totalPage;
var i;var Activity; var status;
$(document).ready(function(){
    $("#fenye").html();
    var i;
    var UserCode= localStorage.getItem('UserCode');
    $.ajax({
        async:true,
        url:"http://47.102.42.105:8181/Task/GetApplyDeviceTask",
        type:"POST",
        dataType:"json",
        data: JSON.stringify({
                "UserCode": UserCode,
                "Page":currentPage,
                "Limit":5,
            }
        ),
        contentType: "application/json",
        success:function(res){
            var tr;
            totalPage = res.pages;
            localStorage.setItem('page',totalPage);
            for (i = 0 ;i<res.msg.length;i++){
                var timestamp1 = res.msg[i].StartTime
                var d1 = new Date(timestamp1 * 1000);
                var date1 = (d1.getFullYear()) + "-" + (d1.getMonth() + 1) + "-" + (d1.getDate()) + "  " + (d1.getHours()) + ":" + (d1.getMinutes()) + ":" + (d1.getSeconds());
                var timestamp2 = res.msg[i].EndTime;
                var d2 = new Date(timestamp2 * 1000);
                var date2 = (d2.getFullYear()) + "-" + (d2.getMonth() + 1) + "-" + (d2.getDate()) + "  " + (d2.getHours()) + ":" + (d2.getMinutes()) + ":" + (d2.getSeconds());
                if(res.msg[i].Activity == 1){
                    Activity = "已授权";
                }else{
                    Activity = "未授权";
                }
                if(res.msg[i].Status == "1"){
                    status = "任务可用";
                }else if(res.msg[i].Status == "0"){
                    status = "未到时间";
                }else{
                    status = "已超时";
                }
                tr = '<td id="Status">'+status+'</td>'+'<td id="TaskCode">'+res.msg[i].TaskCode+'</td>'+'<td id="DeviceUser">'+res.msg[i].DeviceUserName+'</td>'
                    + '<td id="Description">'+res.msg[i].Description+'</td>' + '<td id="StartTime">'+date1+'</td>' + '<td id="EndTime">'+date2+'</td>'
                    + '<td id="DeviceCode">'+res.msg[i].DeviceCode+'</td>' + '<td id="Activity">'+Activity+'</td>'+'<td id="id" width="3%">'+res.msg[i].id+'</td>'
                    +'<td width="4%"><button class="button">审核任务</button></td>'
                $("#table").append('<tr id="current" style="height: 50px;">'+tr+'</tr>');
            }
            $(".button").click(function(){
                var id = $(this).parent().siblings("#id").text();
                $.ajax({
                    async:true,
                    url:"http://47.102.42.105:8181/Task/ApproveApplyDeviceTask",
                    type:"POST",
                    dataType:"json",
                    contentType: "application/json",
                    data: JSON.stringify({ "id":id }),
                    success:function(data) {
                        var flag = data.flag;
                        if(flag == 1){
                            alert("审核成功！")
                        }else {
                            alert("审核失败,请重新审核,或者该任务不存在")
                        }
                    },
                    error:function (data) {
                        alert("审核失败,请重新审核,或者该任务不存在");
                        flag = 0;
                    }
                });
            })
        }
    });
    totalPage = localStorage.getItem('page');
    $('#add').click(function(){
        if(currentPage == totalPage){
            alert("已经是最后一页了");
        }
        else{
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            if(currentPage < totalPage){
                currentPage ++;
                $.ajax({
                    async:true,
                    url:"http://47.102.42.105:8181/Task/GetApplyDeviceTask",
                    type:"POST",
                    dataType:"json",
                    data: JSON.stringify({
                            "UserCode": UserCode,
                            "Page":currentPage,
                            "Limit":5,
                        }
                    ),
                    contentType: "application/json",
                    success:function(res){
                        var tr;
                        totalPage = res.pages;
                        localStorage.setItem('page',totalPage);
                        for (i = 0 ;i<res.msg.length;i++){
                            var timestamp1 = res.msg[i].StartTime
                            var d1 = new Date(timestamp1 * 1000);
                            var date1 = (d1.getFullYear()) + "-" + (d1.getMonth() + 1) + "-" + (d1.getDate()) + "  " + (d1.getHours()) + ":" + (d1.getMinutes()) + ":" + (d1.getSeconds());
                            var timestamp2 = res.msg[i].EndTime;
                            var d2 = new Date(timestamp2 * 1000);
                            var date2 = (d2.getFullYear()) + "-" + (d2.getMonth() + 1) + "-" + (d2.getDate()) + "  " + (d2.getHours()) + ":" + (d2.getMinutes()) + ":" + (d2.getSeconds());
                            if(res.msg[i].Activity == 1){
                                Activity = "已授权";
                            }else{
                                Activity = "未授权";
                            }
                            if(res.msg[i].Status == "1"){
                                status = "任务可用";
                            }else if(res.msg[i].Status == "0"){
                                status = "未到时间";
                            }else{
                                status = "已超时";
                            }
                            tr = '<td id="Status">'+status+'</td>'+'<td id="TaskCode">'+res.msg[i].TaskCode+'</td>'+'<td id="DeviceUser">'+res.msg[i].DeviceUserName+'</td>'
                                + '<td id="Description">'+res.msg[i].Description+'</td>' + '<td id="StartTime">'+date1+'</td>' + '<td id="EndTime">'+date2+'</td>'
                                + '<td id="DeviceCode">'+res.msg[i].DeviceCode+'</td>' + '<td id="Activity">'+Activity+'</td>'+'<td id="id" width="3%">'+res.msg[i].id+'</td>'
                                +'<td width="4%"><button class="button">审核任务</button></td>'
                            $("#table").append('<tr id="current" style="height: 50px;">'+tr+'</tr>');
                        }
                        $(".button").click(function(){
                            var id = $(this).parent().siblings("#id").text();
                            $.ajax({
                                async:true,
                                url:"http://47.102.42.105:8181/Task/ApproveApplyDeviceTask",
                                type:"POST",
                                dataType:"json",
                                contentType: "application/json",
                                data: JSON.stringify({ "id":id }),
                                success:function(data) {
                                    var flag = data.flag;
                                    if(flag == 1){
                                        alert("审核成功！")
                                    }else {
                                        alert("审核失败,请重新审核,或者该任务不存在")
                                    }
                                },
                                error:function (data) {
                                    alert("审核失败,请重新审核,或者该任务不存在");
                                    flag = 0;
                                }
                            });
                        })
                    }
                });
            }
        }
    })
    $('#cut').click(function(){
        if(currentPage == 1){
            alert("已经是第一页了！");
        }else{
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            currentPage --;
            $.ajax({
                async:true,
                url:"http://47.102.42.105:8181/Task/GetApplyDeviceTask",
                type:"POST",
                dataType:"json",
                data: JSON.stringify({
                        "UserCode": UserCode,
                        "Page":currentPage,
                        "Limit":5,
                    }
                ),
                contentType: "application/json",
                success:function(res){
                    var tr;
                    totalPage = res.pages;
                    localStorage.setItem('page',totalPage);
                    for (i = 0 ;i<res.msg.length;i++){
                        var timestamp1 = res.msg[i].StartTime
                        var d1 = new Date(timestamp1 * 1000);
                        var date1 = (d1.getFullYear()) + "-" + (d1.getMonth() + 1) + "-" + (d1.getDate()) + "  " + (d1.getHours()) + ":" + (d1.getMinutes()) + ":" + (d1.getSeconds());
                        var timestamp2 = res.msg[i].EndTime;
                        var d2 = new Date(timestamp2 * 1000);
                        var date2 = (d2.getFullYear()) + "-" + (d2.getMonth() + 1) + "-" + (d2.getDate()) + "  " + (d2.getHours()) + ":" + (d2.getMinutes()) + ":" + (d2.getSeconds());
                        if(res.msg[i].Activity == 1){
                            Activity = "已授权";
                        }else{
                            Activity = "未授权";
                        }
                        if(res.msg[i].Status == "1"){
                            status = "任务可用";
                        }else if(res.msg[i].Status == "0"){
                            status = "未到时间";
                        }else{
                            status = "已超时";
                        }
                        tr = '<td id="Status">'+status+'</td>'+'<td id="TaskCode">'+res.msg[i].TaskCode+'</td>'+'<td id="DeviceUser">'+res.msg[i].DeviceUserName+'</td>'
                            + '<td id="Description">'+res.msg[i].Description+'</td>' + '<td id="StartTime">'+date1+'</td>' + '<td id="EndTime">'+date2+'</td>'
                            + '<td id="DeviceCode">'+res.msg[i].DeviceCode+'</td>' + '<td id="Activity">'+Activity+'</td>'+'<td id="id" width="3%">'+res.msg[i].id+'</td>'
                            +'<td width="4%"><button class="button">审核任务</button></td>'
                        $("#table").append('<tr id="current" style="height: 50px;">'+tr+'</tr>');
                    }
                    $(".button").click(function(){
                        var id = $(this).parent().siblings("#id").text();
                        $.ajax({
                            async:true,
                            url:"http://47.102.42.105:8181/Task/ApproveApplyDeviceTask",
                            type:"POST",
                            dataType:"json",
                            contentType: "application/json",
                            data: JSON.stringify({ "id":id }),
                            success:function(data) {
                                var flag = data.flag;
                                if(flag == 1){
                                    alert("审核成功！")
                                }else {
                                    alert("审核失败,请重新审核,或者该任务不存在")
                                }
                            },
                            error:function (data) {
                                alert("审核失败,请重新审核,或者该任务不存在");
                                flag = 0;
                            }
                        });
                    })
                }
            });
        }
    })
});
totalPage = localStorage.getItem('page');
var audit = new Vue({
    el: '#audit',
    data(){
        return{
            currentPage:0,
            Page: totalPage,
            count : 0,
        };
    },
    methods: {
        turnPage(num) {
            if (num == 1) {
                if (this.currentPage == this.totalPage - 1) {
                    return
                } else {
                    if(this.currentPage<totalPage){
                        this.currentPage++
                    }
                }
            } else {
                if (this.currentPage == 0) {
                    return
                } else {
                    if(this.currentPage>0){
                        this.currentPage--
                    }
                }
            }
        },
    }
})