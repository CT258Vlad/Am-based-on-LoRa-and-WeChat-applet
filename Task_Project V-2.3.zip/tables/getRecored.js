var count = 0;
var currentPage = 1;
var totalPage;
var i;
var UserCode = localStorage.getItem("UserCode");
$(document).ready(function(){
    $("#fenye").html();
    var i;
    var UserCode= localStorage.getItem('UserCode');
    $.ajax({
        async:true,
        url:"http://47.102.42.105:8181/Task/GetRecordByUserCode",
        type:"POST",
        dataType:"json",
        data: JSON.stringify({
                "Page": 1,
                "Limit":5,
                "UserCode":UserCode
            }
        ),
        contentType: "application/json",
        success:function(data){
            var tr;
            totalPage = data.pages;
            localStorage.setItem('page',totalPage);
            for (i = 0 ;i<data.msg.length;i++){
                var timestamp = data.msg[i].CreateTime
                var d = new Date(timestamp * 1000);
                var date = (d.getFullYear()) + "-" + (d.getMonth() + 1) + "-" + (d.getDate()) + "  " + (d.getHours()) + ":" + (d.getMinutes()) + ":" + (d.getSeconds());
                tr='<td id="TaskCode">'+data.msg[i].TaskCode+'</td>'+'<td id="RecordResult">'+data.msg[i].RecordResult+'</td>'
                    + '</td>'+'<td id="DeviceOwnnerName">'+data.msg[i].DeviceOwnnerName+'</td>'
                    + '<td id="CreateTime">'+date+'</td>'
                    + '<td id="PerformerName">'+data.msg[i].PerformerName+'</td>'+'<td id="DeviceCode">'+data.msg[i].DeviceCode+'</td>'
                $("#table").append('<tr id="current" style="height: 50px;">'+tr+'</tr>');
            }
        }
    });
    totalPage = localStorage.getItem('page');
    $('#add').click(function(){
        if(currentPage == totalPage){
            alert("已经是最后一页了")
        }
        else{
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            if(currentPage < totalPage){
                currentPage ++;
                $.ajax({
                    async:true,
                    url:"http://47.102.42.105:8181/Task/GetRecordByUserCode",
                    type:"POST",
                    dataType:"json",
                    data: JSON.stringify({
                            "Page": currentPage,
                            "Limit":5,
                            "UserCode":UserCode
                        }
                    ),
                    contentType: "application/json",
                    success:function(data){
                        var tr;
                        totalPage = data.pages;
                        localStorage.setItem('page',totalPage);
                        for (i = 0 ;i<data.msg.length;i++){
                            var timestamp = data.msg[i].CreateTime
                            var d = new Date(timestamp * 1000);
                            var date = (d.getFullYear()) + "-" + (d.getMonth() + 1) + "-" + (d.getDate()) + "  " + (d.getHours()) + ":" + (d.getMinutes()) + ":" + (d.getSeconds());
                            tr='<td id="TaskCode">'+data.msg[i].TaskCode+'</td>'+'<td id="RecordResult">'+data.msg[i].RecordResult+'</td>'
                                + '</td>'+'<td id="DeviceOwnnerName">'+data.msg[i].DeviceOwnnerName+'</td>'
                                + '<td id="CreateTime">'+date+'</td>'
                                + '<td id="PerformerName">'+data.msg[i].PerformerName+'</td>'+'<td id="DeviceCode">'+data.msg[i].DeviceCode+'</td>'
                            $("#table").append('<tr id="current" style="height: 50px;">'+tr+'</tr>');
                        }
                    }
                });
            }
        }
    })
    $('#cut').click(function(){
        if(currentPage == 1){
            alert("已经是第一页了！");
        }else{
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            $("#current").remove();
            currentPage --;
            $.ajax({
                async:true,
                url:"http://47.102.42.105:8181/Task/GetRecordByUserCode",
                type:"POST",
                dataType:"json",
                data: JSON.stringify({
                        "Page": currentPage,
                        "Limit":5,
                        "UserCode":UserCode
                    }
                ),
                contentType: "application/json",
                success:function(data){
                    var tr;
                    totalPage = data.pages;
                    localStorage.setItem('page',totalPage);
                    for (i = 0 ;i<data.msg.length;i++){
                        var timestamp = data.msg[i].CreateTime
                        var d = new Date(timestamp * 1000);
                        var date = (d.getFullYear()) + "-" + (d.getMonth() + 1) + "-" + (d.getDate()) + "  " + (d.getHours()) + ":" + (d.getMinutes()) + ":" + (d.getSeconds());
                        tr='<td id="TaskCode">'+data.msg[i].TaskCode+'</td>'+'<td id="RecordResult">'+data.msg[i].RecordResult+'</td>'
                            + '</td>'+'<td id="DeviceOwnnerName">'+data.msg[i].DeviceOwnnerName+'</td>'
                            + '<td id="CreateTime">'+date+'</td>'
                            + '<td id="PerformerName">'+data.msg[i].PerformerName+'</td>'+'<td id="DeviceCode">'+data.msg[i].DeviceCode+'</td>'
                        $("#table").append('<tr id="current" style="height: 50px;">'+tr+'</tr>');
                    }
                }
            });
        }
    })
});
totalPage = localStorage.getItem('page');
var audit = new Vue({
    el: '#audit',
    data(){
        return{
            currentPage:0,
            Page: totalPage,
            count : 0,
        };
    },
    methods: {
        turnPage(num) {
            if (num == 1) {
                if (this.currentPage == this.totalPage - 1) {
                    return
                } else {
                    if(this.currentPage<totalPage){
                        this.currentPage++
                    }
                }
            } else {
                if (this.currentPage == 0) {
                    return
                } else {
                    if(this.currentPage>0){
                        this.currentPage--
                    }
                }
            }
        },
    }
})