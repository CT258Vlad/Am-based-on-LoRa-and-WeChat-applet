var value1;
var value2;
var value3;
var value4;
var value5;
var idinfolist1 = [
  { "value1": value1 },
]
var idinfolist2 = [
  { "value2": value2 },
]
var idinfolist3 = [
  { "value3": value3 },
]
var idinfolist4 = [
  { "value4": value4 },
]
var idinfolist5 = [
  { "value5": value5 },
]
Page({
  /**
   * 页面的初始数据
   */
  data: {
    listData1: idinfolist1,
    listData2: idinfolist2,
    listData3: idinfolist3,
    listData4: idinfolist4,
    listData5: idinfolist5,
  },
  btnClick: function (options) {
    console.log("显示数据");
    wx.request({
      url: 'http://182.254.162.240/all',
      method: "POST",
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'chartset': 'utf-8'
      },
      success: function (res) {
        console.log(res.data);  //控制台输出返回数据
        var string = res.data;
        console.log(string);
        for (var i = 0; i < string.length; i++) {
          if (i == 0) {
            value1 = string[i];
          }
          if (i == 1) {
            value2 = string[i];
          }
          if (i == 2) {
            value3 = string[i];
          }
          if (i == 3) {
            value4 = string[i];
          }
          if (i == 4) {
            value5 = string[i];
          }
        }
        console.log(value1);
        console.log(value2);
        console.log(value3);
        console.log(value4);
        console.log(value5);
      },
    });
    this.setData({
      listData1: [
        { "value1": value1+"℃" },
      ],
      listData2: [
        { "value2": value2 },
      ],
      listData3: [
        { "value3": value3+"%" },
      ],
      listData4: [
        { "value4": value4+"%" },
      ],
      listData5: [
        { "value5": value5 },
      ]
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  }
})
