# -*- coding:utf8 -*-
import os

debug = True

HOSTNAME = 'localhost'
PORT = '3306'
DATABASE = 'Lora_Model'
USERNAME = 'root'
PASSWORD = '123456'
DB_URI = "mysql+pymysql://{}:{}@{}:{}/{}?charset=utf8".format(USERNAME, PASSWORD, HOSTNAME, PORT, DATABASE)
SQLALCHEMY_DATABASE_URI = DB_URI

SQLALCHEMY_TRACK_MODIFICATIONS = False

SECRET_KEY = os.urandom(24)
