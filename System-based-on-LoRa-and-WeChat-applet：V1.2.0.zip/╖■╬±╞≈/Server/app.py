# -*- coding:utf8 -*-
from flask_sqlalchemy import SQLAlchemy
from flask import Flask, render_template, redirect, url_for, flash, request, session
from flask_wtf import FlaskForm
from flask_restful import Api, Resource
from flask_login import LoginManager
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, EqualTo, ValidationError
from datetime import datetime
from Server import config
import socket
from time import ctime, sleep
import json, jsonify, requests, os
import re

app = Flask(__name__)
app.config.from_object(config)
db = SQLAlchemy(app)
login_manager = LoginManager(app)
server_socket = " "
onlyone = 0


class User(db.Model):
    __tablename__ = "User"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True, nullable=False)
    Username = db.Column(db.String(30), nullable=False)
    telephone = db.Column(db.String(20), nullable=False)
    password = db.Column(db.String(30), nullable=False)


class Device(db.Model):
    __tabelname__ = 'Device'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True, nullable=False)
    title = db.Column(db.String(10), nullable=False)
    value = db.Column(db.String(10), nullable=False)
    time = db.Column(db.DateTime, default=datetime.now())


class LoginForm(FlaskForm):
    Username = StringField(label=u'用户名', validators=[DataRequired(u"用户名不能为空")])
    password = PasswordField(label=u'密码', validators=[DataRequired(u"密码不能为空")])
    submit = SubmitField(label=u'登录')


class RegisterForm(FlaskForm):
    Username = StringField(label=u'用户名', validators=[DataRequired(u"请输入用户名")])
    telephone = StringField(label=u'手机号码', validators=[DataRequired(u"请输入手机号码")])
    password = PasswordField(label=u'密码', validators=[DataRequired(u"请输入密码")])
    PWD = PasswordField(label=u"确认密码", validators=[DataRequired(u"确认密码不能为空"), EqualTo("password", u'两次密码不一致')])
    submit = SubmitField(label=u'注册')

    def validate_username(self, field):
        if User.query.filter_by(Username=field.data).first():
            raise ValidationError('用户名已注册，请选用其它名称')

    # 自定义邮箱验证器
    def validate_address(self, field):
        if User.query.filter_by(telephone=field.data).first():
            raise ValidationError('该手机号已被使用，请选用其它号码')


@app.route('/')
def index():
    name = session.get("Username", "请先登录")
    return render_template('index.html') + "你好 %s" % name


@app.route('/login/', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        Username = form.Username.data
        password = form.password.data
        user = User.query.first()
        if user:
            if Username == user.Username and password == user.password:
                flash("成功登录！")
                print("用户登录" + "  " + Username, password)
            session['Username'] = Username
            return redirect(url_for("index"))
        else:
            print("未知账号")
    return render_template('login.html', form=form)


@app.route('/logout/')
def logout():
    if LoginForm.Username:
        session.pop('Username')
        return redirect(url_for('index'))
    else:
        return render_template('index.html')


@app.route('/Register/', methods=['GET', 'POST'])
def Register():
    form = RegisterForm()
    if form.validate_on_submit():
        Username = form.Username.data
        telephone = form.telephone.data
        password = form.password.data
        PWD = form.PWD.data
        user = User(Username=Username, telephone=telephone, password=password)
        db.session.add(user)
        db.session.commit()
        flash("注册成功！")
        print("用户注册" + "  " + Username, telephone, password)
        session['Username'] = Username
        return redirect(url_for("index"))

    return render_template('Register.html', form=form)


@app.route('/Device_information', methods=['GET', 'POST'])  # 对设备信息表进行插入操作
def Device_information():
    global server_socket
    print(server_socket)
    initsock()
    receive_data, client = server_socket.recvfrom(1024)
    print("来自客户端%s,发送的%s℃" % (client, receive_data.decode()))
    print(".............")
    data = receive_data.decode()
    print(data)
    temps = re.findall(r".(.+?)t", data)
    for temp in temps[:1]:
        print(temp.title())
    COs = re.findall(r"t(.+?)c", data)
    for CO in COs[:1]:
        print(CO.title())
    Airs = re.findall(r"c(.+?)a", data)
    for Air in Airs[:1]:
        print(Air.title)
    Fires = re.findall(r"a(.+?)f", data)
    for Fire in Fires[:1]:
        print(Fire)
    Humans = re.findall(r"f(.+?)h", data)
    for Human in Humans:
        print(Human)
    value1 = Device(title='温度', value=temp + "℃", time=datetime.now())
    print(value1)
    value2 = Device(title='火焰状态', value=Fire, time=datetime.now())
    print(value2)
    value3 = Device(title='一氧化碳', value=CO + "%", time=datetime.now())
    print(value3)
    value4 = Device(title='有毒气体', value=Air + "%", time=datetime.now())
    print(value4)
    value5 = Device(title='是否有人', value=Human, time=datetime.now())
    print(value5)
    db.session.add_all([value1, value2, value3, value4, value5])
    db.session.commit()
    Device_list = Device.query.all()
    return render_template('Device_information.html', devices=Device_list)


# return json.dumps(data1, ensure_ascii=False)

@app.route('/all', methods=['GET', 'POST'])
def all():
    global server_socket
    print(server_socket)
    initsock()
    receive_data, client = server_socket.recvfrom(1024)
    print("来自客户端%s,发送的%s℃" % (client, receive_data.decode()))
    data = receive_data.decode()
    print(data)
    temps = re.findall(r".(.+?)t", data)
    for temp in temps[:1]:
        print(temp.title())
    # return json.dumps(temp, ensure_ascii=False)
    Fires = re.findall(r"a(.+?)f", data)
    for Fire in Fires[:1]:
        print(Fire)
    # return json.dumps(Fire, ensure_ascii=False)
    COs = re.findall(r"t(.+?)c", data)
    for CO in COs[:1]:
        print(CO.title())
    # return json.dumps(CO, ensure_ascii=False)
    Airs = re.findall(r"c(.+?)a", data)
    for Air in Airs[:1]:
        print(Air.title)
    # return json.dumps(Air, ensure_ascii=False)
    Humans = re.findall(r"f(.+?)h", data)
    for Human in Humans:
        print(Human)
    list = [temp, Fire, CO, Air, Human]
    return json.dumps(list, ensure_ascii=False)
    # return json.dumps(Fire, ensure_ascii=False)
    # return json.dumps(CO, ensure_ascii=False)
    # return json.dumps(Air, ensure_ascii=False)
    # return json.dumps(Human, ensure_ascii=False)


def initsock():
    global server_socket
    global onlyone
    if (onlyone == 1):
        return
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    address = ("172.16.0.16", 1000)
    # 为服务器绑定一个固定的地址，ip和端口
    server_socket.bind(address)
    onlyone = 1
    print(server_socket)


if __name__ == '__main__':
    # db.create_all()
    app.run(
        host="0.0.0.0",
        port=80,
        debug=True
    )
